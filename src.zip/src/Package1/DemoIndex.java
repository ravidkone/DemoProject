package Package1;

public class DemoIndex {

	public void kolkatta()
	{
		System.out.println("This is Kolkatta");
	}
}
