package DemoPackage;

public class DemoConstructor {

	public static void main(String[] args) {
		System.out.println("This is Begining");
      Five f1=new Five();
      f1.bangalore();
	}

}

class Five{
	
	// Five () is constructor and not a method
	Five(){
	System.out.println("This is constructor");	
		
	}
	public void bangalore()
	{
		System.out.println("This is bangalore");
	}
}


// Constructor :

// Constructor name will be same as "Class name"
//Constructor will be called by default when an object is called.
//Constructor will not have any "return type"
